#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 23 05:47:22 2023

@author: zhaozhigen
"""

def add_one(number):
    return number + 1