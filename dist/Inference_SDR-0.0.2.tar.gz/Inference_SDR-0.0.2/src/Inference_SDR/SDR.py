#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 06:41:10 2023

@author: zhigenzhao
"""

class SDR:
    def __init__(self, X, Y, n, p):
        self.X = X
        self.Y = Y
        self.p = p
        self.n = n